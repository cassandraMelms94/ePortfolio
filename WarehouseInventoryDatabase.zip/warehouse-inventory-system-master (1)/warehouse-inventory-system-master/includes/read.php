/*
|--------------------------------------------------------------------------
| Read functionality
|--------------------------------------------------------------------------
| Author: Cassandra melms
| Project Name: CRUD-Complete
| Offcial page: https://github.com/cassandraMelms94/SNHUwork/
|
|
|
*/
<?php
$myfile = fopen("sql.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("sql.php"));
fclose($myfile);
?>
<?php
$myfile = fopen("config.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("config.php"));
fclose($myfile);
?>
<?php
$myfile = fopen("database.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("database.php"));
fclose($myfile);
?>
<?php
$myfile = fopen("functions.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("functions.php"));
fclose($myfile);
?>
<?php
$myfile = fopen("session.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("session.php"));
fclose($myfile);
?>
<?php
$myfile = fopen("upload.php", "r") or die ("Unable to open file!");
echo fread($myfile, filesize("upload.php"));
fclose($myfile);
?>